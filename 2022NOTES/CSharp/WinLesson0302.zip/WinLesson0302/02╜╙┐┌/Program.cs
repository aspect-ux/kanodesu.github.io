﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02接口
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region 2.在上题中，描述喜鹊和老鹰都可以飞，扩展：飞机也可以飞。（提示：接口）
            IFlyable[] flyables = { 
                new Magpie(),
                new Eagle(),
                new Plane()
            };
            foreach (var item in flyables)
            {
                item.Fly();
            }
            Console.ReadKey();
            #endregion
        }
    }
    interface IFlyable
    {
        void Fly();
    }
    /// <summary>
    /// 父类：Bird
    /// </summary>
    abstract class Bird
    {
        //public virtual void Eat()
        //{
        //    Console.WriteLine("我是一只小小鸟，喜欢吃虫子");
        //}
        public abstract void Eat();
    }

    /// <summary>
    /// 子类：Magpie
    /// </summary>
    class Magpie : Bird, IFlyable
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只喜鹊，喜欢吃虫子");
        }

        public void Fly()
        {
            Console.WriteLine("喜鹊会飞。");
        }
    }

    /// <summary>
    /// 子类：Eagle
    /// </summary>
    class Eagle : Bird,IFlyable
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只老鹰，喜欢吃肉");
        }

        public void Fly()
        {
            Console.WriteLine("老鹰会飞。");
        }
    }

    /// <summary>
    /// 子类：Penguin
    /// </summary>
    class Penguin : Bird
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只企鹅，喜欢吃鱼");
        }
    }

    class Plane : IFlyable
    {
        public void Fly()
        {
            Console.WriteLine("飞机也会飞啊。。");
        }
    }
}
