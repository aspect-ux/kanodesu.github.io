﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03委托
{
    //public delegate void MyDelegate();
    internal class Program
    {
        static void Main(string[] args)
        {
            //MyDelegate myDelegate = new MyDelegate(M1);
            //M1();
            //myDelegate();
            //Action ac1 = new Action(M1);
            //ac1();
            //Action<string> ac2 = new Action<string>(M2);
            //ac2("hello world");
            //Func<int,int> ac3 = new Func<int,int>(M3);
            //int result = ac3(10);
            //Console.WriteLine(result);
            Action action = new Action(
                () => {
                    Console.WriteLine("方法M1，我是一个无参无返回值的方法。");
                }
                );
            action();
            Console.ReadKey();
        }

        //public static void M1()
        //{
        //    Console.WriteLine("方法M1，我是一个无参无返回值的方法。");
        //}

        public static void M2(string msg)
        {
            Console.WriteLine($"方法M2，我是一个有参无返回值的方法。参数信息为：{msg}");
        }

        public static int M3(int msg)
        {
            Console.WriteLine($"方法M3，我是一个有参有返回值的方法。参数信息为：{msg}");
            return msg*2;
        }
    }
}
