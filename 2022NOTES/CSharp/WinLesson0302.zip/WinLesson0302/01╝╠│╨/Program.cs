﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01继承
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region 1.喜鹊（Magpie）、老鹰（Eagle）、企鹅（Penguin）都是属于鸟类，我们可以根据这三者的共有特性提取出鸟类（Bird）做为父类，喜鹊喜欢吃虫子，老鹰喜欢吃肉，企鹅喜欢吃鱼。（提示：虚方法与抽象方法）
            Bird[] birds = new Bird[] { 
                //new Bird(),
                new Magpie(),
                new Eagle(),
                new Penguin()
            };
            foreach (Bird item in birds)
            {
                item.Eat();
            }
            Console.ReadKey();
            #endregion
        }
    }
    /// <summary>
    /// 父类：Bird
    /// </summary>
    abstract class Bird
    {
        //public virtual void Eat()
        //{
        //    Console.WriteLine("我是一只小小鸟，喜欢吃虫子");
        //}
        public abstract void Eat();
    }

    /// <summary>
    /// 子类：Magpie
    /// </summary>
    class Magpie : Bird
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只喜鹊，喜欢吃虫子");
        }
    }

    /// <summary>
    /// 子类：Eagle
    /// </summary>
    class Eagle : Bird
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只老鹰，喜欢吃肉");
        }
    }

    /// <summary>
    /// 子类：Penguin
    /// </summary>
    class Penguin : Bird
    {
        public override void Eat()
        {
            Console.WriteLine("我是一只企鹅，喜欢吃鱼");
        }
    }
}
